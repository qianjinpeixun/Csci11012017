javac Robot.java
javac -cp . RobotGame.java
java -cp . RobotGame


javac Hangman.java
javac -cp . Hangmandemo.java
java -cp . Hangmandemo

